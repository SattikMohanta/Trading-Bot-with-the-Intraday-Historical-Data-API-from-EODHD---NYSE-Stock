# Cosine
A modular open source cryptocurrency trading algo framework. You can check out the documentation [here](https://cosine-documentation.readthedocs.io/en/latest/).
