# parallel (dask?)
# chunk processing

# merge?

# datetime / timestamp parser
